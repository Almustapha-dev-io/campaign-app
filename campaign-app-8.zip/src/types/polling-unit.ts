import { TWard } from './ward';

export type TPollingUnit = {
  id: number;
  name: string;
  ward: TWard;
};
