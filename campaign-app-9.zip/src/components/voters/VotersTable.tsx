import React from 'react';

function VotersTable() {
  return <div>VotersTable</div>;
}

export default VotersTable;
