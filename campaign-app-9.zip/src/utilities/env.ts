export const apiBaseURL = process.env.REACT_APP_API_BASE_URL ?? '';
export const cloudinaryPreset = process.env.REACT_APP_CD_PRESET ?? '';
export const cloudinaryCloudName = process.env.REACT_APP_CD_NAME ?? '';
export const cloudinaryUploadAPI = process.env.REACT_APP_IMAGE_UPLOAD_API ?? '';
